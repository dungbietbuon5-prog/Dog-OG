// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    
    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    
    // Trạng thái các nút
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var antennaEnabled = false
    @State private var fps144Enabled = false
    @State private var aimBodyEnabled = false
    @State private var aimChestEnabled = false
    @State private var magicEnabled = false

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop().ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    gameLaunchPanel
                    footerStatus
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear { syncPatchStates() }
    }

    // --- GIAO DIỆN CƠ BẢN ---
    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("OGIOS").font(.system(size: 25, weight: .black)).tracking(3).foregroundStyle(.white)
                Text("PATCH CONTROL CENTER").font(.system(size: 10, weight: .bold)).tracking(1.7).foregroundStyle(.red)
            }
            Spacer()
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            HStack { Image(systemName: "shield.fill").foregroundColor(.red); Text("DEVICE STATUS").font(.system(size: 12, weight: .black)).foregroundStyle(.red); Spacer() }
            statusRow(icon: "apple.logo", title: "iOS", value: UIDevice.current.systemVersion, color: .red)
            statusRow(icon: "iphone", title: "Device", value: "iPhone", color: .red)
            statusRow(icon: "checkmark.seal.fill", title: "Support", value: "UNSUPPORTED", color: .red)
        }
        .padding(16)
        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.red.opacity(0.38), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("PATCH OPTIONS").font(.system(size: 12, weight: .black)).foregroundStyle(.red); Spacer(); Text("SELECT TO ENABLE").font(.system(size: 9, weight: .bold)).foregroundStyle(.white.opacity(0.45)) }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCard(name: "Aim Drag", file: "AimDrag.3105", state: $aimDragEnabled)
                patchCard(name: "Aim Neck", file: "AimNeck.3105", state: $aimNeckEnabled)
                patchCard(name: "Antenna", file: "Antenna.3105", state: $antennaEnabled)
                patchCard(name: "144 FPS", file: "144FPS.3105", state: $fps144Enabled)
                patchCard(name: "Aim Body", file: "AimBody.3105", state: $aimBodyEnabled)
                patchCard(name: "Aim Chest", file: "AimChest.3105", state: $aimChestEnabled)
                patchCard(name: "Magic", file: "Magic.3105", state: $magicEnabled)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.contains("Success") ? .green : .red).frame(width: 7, height: 7)
                Text(patchMessage).font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.72))
                Spacer()
            }.padding(.horizontal, 12).padding(.vertical, 10).background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCard(name: String, file: String, state: Binding<Bool>) -> some View {
        Button(action: {
            togglePatch(patchName: file, state: state)
        }) {
            VStack(alignment: .leading, spacing: 11) {
                HStack {
                    Image(systemName: "bolt.fill").foregroundStyle(.red)
                    Spacer()
                    Text(state.wrappedValue ? "ON" : "OFF").font(.system(size: 11, weight: .black)).foregroundStyle(state.wrappedValue ? .green : .white.opacity(0.58))
                }
                Text(name).font(.system(size: 17, weight: .black)).foregroundStyle(.white)
                Text("FREE FIRE • NORMAL").font(.system(size: 10, weight: .black)).tracking(1.3).foregroundStyle(.red)
                HStack(spacing: 7) {
                    Circle().fill(state.wrappedValue ? Color.green : Color.white.opacity(0.25)).frame(width: 8, height: 8)
                    Text(state.wrappedValue ? "PATCH ACTIVE" : "ACTIVATE PATCH").font(.system(size: 9, weight: .black)).foregroundStyle(.white.opacity(0.65))
                }
            }
            .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
            .padding(14)
            .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(state.wrappedValue ? Color.red : Color.red.opacity(0.28), lineWidth: state.wrappedValue ? 1.5 : 1))
        }
        .buttonStyle(.plain)
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("LAUNCH GAME").font(.system(size: 12, weight: .black)).foregroundStyle(.red)
            HStack(spacing: 12) {
                Button { openGame(scheme: "freefireth") } label: {
                    Text("FF NORMAL").font(.system(size: 13, weight: .black)).foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 52)
                        .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.red.opacity(0.52), lineWidth: 1))
                }
            }
            Button { cleanPatches() } label: {
                Text("Clean Cache & Temp").font(.system(size: 13, weight: .black)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.red.opacity(0.52), lineWidth: 1))
            }
        }
    }

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle().fill(.green).frame(width: 9, height: 9)
            Text("SISTEMA PRONTO").font(.system(size: 10, weight: .black)).foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text("OGIOS • PRONTO").font(.system(size: 9, weight: .bold)).foregroundStyle(.red.opacity(0.8))
        }.padding(.horizontal, 14).padding(.vertical, 13).background(Color.black.opacity(0.45), in: Capsule())
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).foregroundStyle(color).frame(width: 24)
            Text(title).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).fontWeight(.black).foregroundStyle(.white)
        }.padding(.top, 14)
    }

    // --- LOGIC TÌM VÀ PATCH FILE ---
    
    // Hàm tự động quét tìm file trong App
    func findPatchFile(fileName: String) -> String? {
        guard let bundlePath = Bundle.main.resourcePath else { return nil }
        let fileManager = FileManager.default
        if let enumerator = fileManager.enumerator(atPath: bundlePath) {
            for case let path as String in enumerator {
                if path.hasSuffix(fileName) {
                    return "\(bundlePath)/\(path)"
                }
            }
        }
        return nil
    }

    func togglePatch(patchName: String, state: Binding<Bool>) {
        state.wrappedValue.toggle()
        
        if state.wrappedValue {
            // Bật Patch
            if let realPath = findPatchFile(fileName: patchName) {
                patchMessage = "PATCHED \(patchName)"
                print("Đã tìm thấy \(patchName) tại \(realPath)")
                
                // ĐƯỜNG DẪN ĐÍCH (MÀY PHẢI SỬA ĐƯỜNG DẪN GAME FF CỦA MÀY VÀO ĐÂY)
                let gamePatchDir = "/var/mobile/Containers/Data/Application/XXXX-XXXX-XXXX-XXXX/Documents/"
                let destPath = gamePatchDir + patchName
                
                do {
                    if FileManager.default.fileExists(atPath: destPath) {
                        try FileManager.default.removeItem(atPath: destPath)
                    }
                    try FileManager.default.copyItem(atPath: realPath, toPath: destPath)
                    print("Đã copy file patch vào game.")
                } catch {
                    patchMessage = "LỖI COPY: \(error.localizedDescription)"
                }
            } else {
                patchMessage = "LỖI: KHÔNG TÌM THẤY \(patchName)"
                state.wrappedValue = false
            }
        } else {
            patchMessage = "READY — SELECT A PATCH"
        }
    }

    func cleanPatches() {
        patchMessage = "ĐÃ XÓA PATCH (KHÔI PHỤC GỐC)"
        let gamePatchDir = "/var/mobile/Containers/Data/Application/XXXX-XXXX-XXXX-XXXX/Documents/"
        let patchNames = ["AimDrag.3105", "AimNeck.3105", "Antenna.3105", "144FPS.3105", "AimBody.3105", "AimChest.3105", "Magic.3105"]
        for name in patchNames {
            let filePath = gamePatchDir + name
            try? FileManager.default.removeItem(atPath: filePath)
        }
    }

    func syncPatchStates() {
        // Đồng bộ trạng thái các nút nếu cần
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}

// --- BACKGROUND & COMPONENTS GIỮ NGUYÊN ---
struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color(red: 0.05, green: 0.02, blue: 0.02)
                Circle().fill(Color.red.opacity(0.12)).frame(width: 280, height: 280).blur(radius: 70)
            }
        }
    }
}