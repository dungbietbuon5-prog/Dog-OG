// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit

struct ContentView: View {
    // Thông tin thiết bị
    let iosVersion = UIDevice.current.systemVersion
    var deviceModel: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        return machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
    }
    
    // Trạng thái các nút
    @State private var isAimDragOn = false
    @State private var isAimNeckOn = false
    @State private var isAimBotOn = false
    @State private var isAimMagicOn = false
    
    @State private var statusText = "READY — SELECT A PATCH"
    
    // Màu sắc
    let bgColor = Color(red: 0.05, green: 0.02, blue: 0.02)
    let cardBgColor = Color(red: 0.1, green: 0.05, blue: 0.05)
    let redColor = Color.red

    var body: some View {
        ZStack {
            bgColor.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // --- HEADER ---
                    VStack(alignment: .leading, spacing: 5) {
                        Text("OGIOS")
                            .font(.system(size: 40, weight: .heavy))
                            .foregroundColor(.white)
                        
                        Text("PATCH CONTROL CENTER")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(redColor)
                            .tracking(2)
                    }
                    .padding(.top, 20)
                    .padding(.horizontal)
                    
                    // --- DEVICE STATUS ---
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "shield.fill").foregroundColor(redColor)
                            Text("DEVICE STATUS").font(.caption).fontWeight(.bold).foregroundColor(redColor)
                        }
                        
                        HStack {
                            Image(systemName: "applelogo")
                            Text("iOS")
                            Spacer()
                            Text(iosVersion).fontWeight(.bold)
                        }.foregroundColor(.white)
                        
                        Divider().background(Color.gray.opacity(0.3))
                        
                        HStack {
                            Image(systemName: "iphone")
                            Text("Device")
                            Spacer()
                            Text(deviceModel).fontWeight(.bold)
                        }.foregroundColor(.white)

                        Divider().background(Color.gray.opacity(0.3))

                        HStack {
                            Image(systemName: "checkmark.shield.fill").foregroundColor(redColor)
                            Text("Support")
                            Spacer()
                            Text("UNSUPPORTED").fontWeight(.bold).foregroundColor(redColor)
                        }
                    }
                    .padding()
                    .background(cardBgColor)
                    .cornerRadius(15)
                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(redColor.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal)
                    
                    // --- PATCH OPTIONS ---
                    HStack {
                        Image(systemName: "bolt.fill").foregroundColor(redColor)
                        Text("PATCH OPTIONS").font(.caption).fontWeight(.bold).foregroundColor(redColor)
                        Spacer()
                        Text("SELECT TO ENABLE").font(.caption2).foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                        PatchCard(title: "Aim Drag", isOn: $isAimDragOn, cardBg: cardBgColor, redColor: redColor)
                            .onChange(of: isAimDragOn) { _ in updateStatus() }
                        
                        PatchCard(title: "Aim Neck", isOn: $isAimNeckOn, cardBg: cardBgColor, redColor: redColor)
                            .onChange(of: isAimNeckOn) { _ in updateStatus() }
                        
                        PatchCard(title: "Aim Bot", isOn: $isAimBotOn, cardBg: cardBgColor, redColor: redColor)
                            .onChange(of: isAimBotOn) { _ in updateStatus() }
                        
                        PatchCard(title: "Aim Magic", isOn: $isAimMagicOn, cardBg: cardBgColor, redColor: redColor)
                            .onChange(of: isAimMagicOn) { _ in updateStatus() }
                    }
                    .padding(.horizontal)
                    
                    // --- READY STATUS ---
                    HStack {
                        Circle()
                            .fill(isAnyPatchSelected() ? Color.green : redColor)
                            .frame(width: 8, height: 8)
                        Text(statusText).font(.caption).foregroundColor(.white)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    // --- LAUNCH GAME ---
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "gamecontroller.fill").foregroundColor(redColor)
                            Text("LAUNCH GAME").font(.caption).fontWeight(.bold).foregroundColor(redColor)
                        }
                        
                        HStack(spacing: 15) {
                            // Nút FF Normal
                            Button(action: {
                                if isAnyPatchSelected() {
                                    applyPatchesAndLaunch()
                                } else {
                                    statusText = "PLEASE SELECT A PATCH FIRST"
                                }
                            }) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack {
                                        Image(systemName: "arrow.up.right.square.fill")
                                            .foregroundColor(.white)
                                            .padding(6)
                                            .background(redColor)
                                            .cornerRadius(5)
                                        Spacer()
                                    }
                                    Text("FF NORMAL").font(.headline).foregroundColor(.white)
                                    Text("Free Fire Normal").font(.caption2).foregroundColor(.gray)
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(cardBgColor)
                                .cornerRadius(15)
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(redColor, lineWidth: 1))
                            }
                            
                            // Nút FF Max (Khóa)
                            Button(action: {}) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack {
                                        Image(systemName: "lock.fill").foregroundColor(.gray)
                                        Spacer()
                                    }
                                    Text("FF MAX").font(.headline).foregroundColor(.gray)
                                    Text("Locked • Coming Soon").font(.caption2).foregroundColor(.gray)
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(cardBgColor)
                                .cornerRadius(15)
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.gray.opacity(0.5), lineWidth: 1))
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    // --- CLEAN CACHE & TEMP (CÓ CHỨC NĂNG XÓA PATCH) ---
                    Button(action: {
                        cleanPatches()
                    }) {
                        HStack {
                            Image(systemName: "trash.fill")
                            Text("Clean Cache & Temp").fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(cardBgColor)
                        .cornerRadius(15)
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(redColor, lineWidth: 1))
                    }
                    .padding(.horizontal)
                    
                    // --- FOOTER ---
                    VStack(spacing: 10) {
                        HStack {
                            Circle().fill(Color.green).frame(width: 10, height: 10)
                            Text("SISTEMA PRONTO").font(.caption).fontWeight(.bold)
                            Spacer()
                            Text("OGIOS • PRONTO").font(.caption).foregroundColor(redColor)
                        }
                        .padding()
                        .background(cardBgColor)
                        .cornerRadius(20)
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.green.opacity(0.3), lineWidth: 1))
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                }
            }
        }
    }
    
    // --- HÀM HỖ TRỢ ---
    func isAnyPatchSelected() -> Bool {
        return isAimDragOn || isAimNeckOn || isAimBotOn || isAimMagicOn
    }
    
    func updateStatus() {
        if isAnyPatchSelected() {
            statusText = "READY — PATCH SELECTED"
        } else {
            statusText = "READY — SELECT A PATCH"
        }
    }
    
    // Tự động quét tìm file trong App Bundle
    func findFileInBundle(fileName: String, bundlePath: String) -> String? {
        let fileManager = FileManager.default
        if let enumerator = fileManager.enumerator(atPath: bundlePath) {
            for case let path as String in enumerator {
                if path.hasSuffix(fileName) {
                    return "\(bundlePath)/\(path)"
                }
            }
        }
        return nil
    }
    
    // Hàm Patch và Mở Game
    func applyPatchesAndLaunch() {
        guard let bundlePath = Bundle.main.resourcePath else { return }
        var patchName: String? = nil
        
        if isAimNeckOn { patchName = "AimNeck.3105" }
        else if isAimDragOn { patchName = "AimDrag.3105" }
        else if isAimBotOn { patchName = "Aimbot.3105" }
        else if isAimMagicOn { patchName = "AimMagic.3105" }
        
        if let name = patchName {
            if let realPath = findFileInBundle(fileName: name, bundlePath: bundlePath) {
                statusText = "ĐÃ PATCH \(name)"
                
                // ĐƯỜNG DẪN GAME (MÀY SỬA LẠI ĐƯỜNG DẪN THẬT CỦA GAME FF TRÊN MÁY MÀY)
                // Thay chuỗi XXXX... bằng đường dẫn thật bạn tìm thấy bằng Filza
                let gamePatchDir = "/var/mobile/Containers/Data/Application/XXXX-XXXX-XXXX-XXXX/Documents/"
                let destPath = gamePatchDir + name
                
                do {
                    if FileManager.default.fileExists(atPath: destPath) {
                        try FileManager.default.removeItem(atPath: destPath)
                    }
                    try FileManager.default.copyItem(atPath: realPath, toPath: destPath)
                    print("Đã copy patch vào game.")
                } catch {
                    print("Lỗi copy file: \(error)")
                }
            } else {
                statusText = "LỖI: KHÔNG TÌM THẤY \(name)"
                return
            }
        }
        
        // Mở Game
        let freeFireURL = URL(string: "freefire://")!
        if UIApplication.shared.canOpenURL(freeFireURL) {
            UIApplication.shared.open(freeFireURL, options: [:], completionHandler: nil)
        }
    }
    
    // Hàm Xóa Patch (Khôi phục file gốc)
    func cleanPatches() {
        // ĐƯỜNG DẪN GAME (MÀY SỬA LẠI ĐƯỜNG DẪN THẬT CỦA GAME FF)
        let gamePatchDir = "/var/mobile/Containers/Data/Application/XXXX-XXXX-XXXX-XXXX/Documents/"
        
        let patchNames = ["AimDrag.3105", "AimNeck.3105", "Aimbot.3105", "AimMagic.3105"]
        var deletedCount = 0
        
        for name in patchNames {
            let filePath = gamePatchDir + name
            if FileManager.default.fileExists(atPath: filePath) {
                do {
                    try FileManager.default.removeItem(atPath: filePath)
                    deletedCount += 1
                } catch {
                    print("Lỗi xóa file \(name): \(error)")
                }
            }
        }
        
        if deletedCount > 0 {
            statusText = "ĐÃ XÓA \(deletedCount) PATCH (ĐÃ KHÔI PHỤC GỐC)"
        } else {
            statusText = "KHÔNG CÓ PATCH NÀO ĐỂ XÓA"
        }
    }
}

// --- COMPONENT NÚT BẤM ---
struct PatchCard: View {
    var title: String
    @Binding var isOn: Bool
    var cardBg: Color
    var redColor: Color
    
    var body: some View {
        Button(action: { isOn.toggle() }) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "bolt.fill").foregroundColor(isOn ? redColor : .white)
                    Spacer()
                    Text(isOn ? "ON" : "OFF").font(.caption).fontWeight(.bold).foregroundColor(isOn ? .white : .gray)
                }
                Text(title).font(.title3).fontWeight(.heavy).foregroundColor(.white)
                Text("FREE FIRE • NORMAL").font(.caption2).fontWeight(.bold).foregroundColor(redColor)
                
                HStack {
                    Circle().fill(isOn ? redColor : Color.gray).frame(width: 8, height: 8)
                    Text("ACTIVATE PATCH").font(.caption2).fontWeight(.bold).foregroundColor(isOn ? .white : .gray)
                }
                .padding(.top, 5)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(cardBg)
            .cornerRadius(15)
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(isOn ? redColor : Color.gray.opacity(0.3), lineWidth: 1))
        }
        .buttonStyle(PlainButtonStyle())
    }
}