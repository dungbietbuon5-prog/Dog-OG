// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit

struct PatchItem: Identifiable {
    let id = UUID()
    let name: String
    let isEnabled: Bool
}

struct ContentView: View {
    @State private var showSettings = false
    @State private var patches = [
        PatchItem(name: "Aim Drag", isEnabled: true),
        PatchItem(name: "Aim Magic", isEnabled: true),
        PatchItem(name: "Aim Bot", isEnabled: false),
        PatchItem(name: "Aim Neck", isEnabled: false)
    ]

    var body: some View {
        ZStack {
            // Nền đen tuyền
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // --- HEADER ---
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("TRUNG DŨNG")
                            .font(.system(size: 28, weight: .black, design: .monospaced))
                            .foregroundColor(.white)
                            .shadow(color: .red, radius: 5)
                        Text("AIM CONTROL SYSTEM")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(.red)
                            .tracking(2)
                    }
                    
                    Spacer()
                    
                    Button(action: { showSettings = true }) {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.red)
                            .padding(10)
                            .background(Color.red.opacity(0.1))
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.red.opacity(0.5), lineWidth: 1))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // --- DANH SÁCH PATCH ---
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach($patches) { $patch in
                            PatchRow(patch: $patch)
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }
}

// --- COMPONENT ROW ---
struct PatchRow: View {
    @Binding var patch: PatchItem
    
    var body: some View {
        HStack {
            // Icon
            Image(systemName: "scope")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(patch.isEnabled ? .black : .gray)
                .frame(width: 40, height: 40)
                .background(patch.isEnabled ? Color.red : Color.gray.opacity(0.2))
                .cornerRadius(10)
            
            // Tên
            Text(patch.name)
                .font(.system(size: 16, weight: .bold, design: .monospaced))
                .foregroundColor(patch.isEnabled ? .white : .gray)
            
            Spacer()
            
            // Nút gạt tự chế (Neon)
            Button(action: {
                withAnimation(.easeInOut(duration: 0.2)) {
                    patch.isEnabled.toggle()
                }
            }) {
                Text(patch.isEnabled ? "ON" : "OFF")
                    .font(.system(size: 12, weight: .black, design: .monospaced))
                    .foregroundColor(patch.isEnabled ? .black : .gray)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(patch.isEnabled ? Color.red : Color.black)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(patch.isEnabled ? Color.red : Color.gray.opacity(0.5), lineWidth: 1)
                    )
                    .shadow(color: patch.isEnabled ? .red.opacity(0.5) : .clear, radius: 5)
            }
        }
        .padding()
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(patch.isEnabled ? Color.red.opacity(0.5) : Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
}

// --- SETTINGS VIEW (Giao diện thông tin) ---
struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    let iosVersion = UIDevice.current.systemVersion
    let deviceName = UIDevice.current.name
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("THÔNG TIN HỆ THỐNG")
                    .font(.system(size: 18, weight: .black, design: .monospaced))
                    .foregroundColor(.red)
                    .padding(.top, 20)
                
                VStack(spacing: 0) {
                    InfoRow(title: "Thiết bị", value: deviceName)
                    Divider().background(Color.gray.opacity(0.2))
                    InfoRow(title: "Phiên bản iOS", value: iosVersion)
                    Divider().background(Color.gray.opacity(0.2))
                    InfoRow(title: "Trạng thái", value: "Hoạt động")
                }
                .background(Color(red: 0.1, green: 0.1, blue: 0.1))
                .cornerRadius(12)
                .padding(.horizontal, 20)
                
                Button(action: { dismiss() }) {
                    Text("ĐÓNG")
                        .font(.system(size: 14, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                Spacer()
            }
        }
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    var body: some View {
        HStack {
            Text(title).foregroundColor(.gray).font(.system(size: 14, design: .monospaced))
            Spacer()
            Text(value).foregroundColor(.white).font(.system(size: 14, weight: .bold, design: .monospaced))
        }
        .padding()
    }
}