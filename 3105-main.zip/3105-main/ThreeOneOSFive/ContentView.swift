// language: Swift, file: ContentView.swift

import SwiftUI

struct ContentView: View {
    // Trạng thái Bật/Tắt của từng chức năng
    @State private var isAimDragOn = false
    @State private var isAimNeckOn = false
    @State private var isAimBotOn = false
    @State private var isAimMagicOn = false
    
    // Màu chủ đạo
    let bgColor = Color(red: 0.05, green: 0.02, blue: 0.02) // Đen ánh đỏ
    let cardBgColor = Color(red: 0.1, green: 0.05, blue: 0.05) // Đen xám
    let redColor = Color.red
    let textColor = Color.white

    var body: some View {
        ZStack {
            bgColor.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // --- HEADER ---
                    VStack(alignment: .leading, spacing: 5) {
                        Text("OGIOS")
                            .font(.system(size: 40, weight: .heavy))
                            .foregroundColor(.white)
                        
                        Text("PATCH CONTROL CENTER")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(redColor)
                            .tracking(2)
                    }
                    .padding(.top, 20)
                    .padding(.horizontal)
                    
                    // --- DEVICE STATUS ---
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "shield.fill")
                                .foregroundColor(redColor)
                            Text("DEVICE STATUS")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(redColor)
                        }
                        
                        HStack {
                            Image(systemName: "applelogo")
                            Text("iOS")
                            Spacer()
                            Text("27.0.0").fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        
                        Divider().background(Color.gray.opacity(0.3))
                        
                        HStack {
                            Image(systemName: "iphone")
                            Text("Device")
                            Spacer()
                            Text("iPhone14,5").fontWeight(.bold)
                        }
                        .foregroundColor(.white)

                        Divider().background(Color.gray.opacity(0.3))

                        HStack {
                            Image(systemName: "checkmark.shield.fill")
                                .foregroundColor(redColor)
                            Text("Support")
                            Spacer()
                            Text("UNSUPPORTED").fontWeight(.bold).foregroundColor(redColor)
                        }
                    }
                    .padding()
                    .background(cardBgColor)
                    .cornerRadius(15)
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(redColor.opacity(0.3), lineWidth: 1)
                    )
                    .padding(.horizontal)
                    
                    // --- PATCH OPTIONS ---
                    HStack {
                        Image(systemName: "bolt.fill")
                            .foregroundColor(redColor)
                        Text("PATCH OPTIONS")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(redColor)
                        Spacer()
                        Text("SELECT TO ENABLE")
                            .font(.caption2)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    // Lưới 2x2 chứa các nút bấm
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                        
                        PatchCard(title: "Aim Drag", isOn: $isAimDragOn, cardBg: cardBgColor, redColor: redColor)
                        
                        PatchCard(title: "Aim Neck", isOn: $isAimNeckOn, cardBg: cardBgColor, redColor: redColor)
                        
                        PatchCard(title: "Aim Bot", isOn: $isAimBotOn, cardBg: cardBgColor, redColor: redColor)
                        
                        PatchCard(title: "Aim Magic", isOn: $isAimMagicOn, cardBg: cardBgColor, redColor: redColor)
                        
                    }
                    .padding(.horizontal)
                    
                    // --- TRẠNG THÁI READY ---
                    HStack {
                        Circle()
                            .fill(redColor)
                            .frame(width: 8, height: 8)
                        Text("READY — SELECT A PATCH")
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    // --- NÚT LAUNCH GAME ---
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "gamecontroller.fill")
                                .foregroundColor(redColor)
                            Text("LAUNCH GAME")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(redColor)
                        }
                        
                        HStack(spacing: 15) {
                            // Nút FF Normal
                            Button(action: {
                                // Code khởi chạy game
                            }) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack {
                                        Image(systemName: "arrow.up.right.square.fill")
                                            .foregroundColor(.white)
                                            .padding(6)
                                            .background(redColor)
                                            .cornerRadius(5)
                                        Spacer()
                                    }
                                    Text("FF NORMAL")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    Text("Free Fire Normal")
                                        .font(.caption2)
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(cardBgColor)
                                .cornerRadius(15)
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(redColor, lineWidth: 1))
                            }
                            
                            // Nút FF Max (Khóa)
                            Button(action: {}) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack {
                                        Image(systemName: "lock.fill")
                                            .foregroundColor(.gray)
                                        Spacer()
                                    }
                                    Text("FF MAX")
                                        .font(.headline)
                                        .foregroundColor(.gray)
                                    Text("Locked • Coming Soon")
                                        .font(.caption2)
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(cardBgColor)
                                .cornerRadius(15)
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.gray.opacity(0.5), lineWidth: 1))
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    // --- NÚT CLEAN CACHE ---
                    Button(action: {
                        // Code xóa cache
                    }) {
                        HStack {
                            Image(systemName: "trash.fill")
                            Text("Clean Cache & Temp")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(cardBgColor)
                        .cornerRadius(15)
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(redColor, lineWidth: 1))
                    }
                    .padding(.horizontal)
                    
                    // --- FOOTER ---
                    VStack(spacing: 10) {
                        HStack {
                            Circle().fill(Color.green).frame(width: 10, height: 10)
                            Text("SISTEMA PRONTO")
                                .font(.caption)
                                .fontWeight(.bold)
                            Spacer()
                            Text("OGIOS • PRONTO")
                                .font(.caption)
                                .foregroundColor(redColor)
                        }
                        .padding()
                        .background(cardBgColor)
                        .cornerRadius(20)
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.green.opacity(0.3), lineWidth: 1))
                        
                        Text("Developed by OGIOS")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .padding(.top, 10)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                }
            }
        }
    }
}

// --- COMPONENT CHO CÁC NÚT BẤM (CARD) ---
struct PatchCard: View {
    var title: String
    @Binding var isOn: Bool
    var cardBg: Color
    var redColor: Color
    
    var body: some View {
        Button(action: {
            isOn.toggle()
        }) {
            VStack(alignment: .leading, spacing: 10) {
                // Icon tia sét và trạng thái
                HStack {
                    Image(systemName: "bolt.fill")
                        .foregroundColor(isOn ? redColor : .white)
                    Spacer()
                    Text(isOn ? "ON" : "OFF")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(isOn ? .white : .gray)
                }
                
                // Tên chức năng
                Text(title)
                    .font(.title3)
                    .fontWeight(.heavy)
                    .foregroundColor(.white)
                
                // Subtitle (FF NORMAL)
                Text("FREE FIRE • NORMAL")
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundColor(redColor)
                
                // Dòng Activate
                HStack {
                    Circle()
                        .fill(isOn ? redColor : Color.gray)
                        .frame(width: 8, height: 8)
                    Text("ACTIVATE PATCH")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(isOn ? .white : .gray)
                }
                .padding(.top, 5)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(cardBg)
            .cornerRadius(15)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(isOn ? redColor : Color.gray.opacity(0.3), lineWidth: 1)
            )
        }
        .buttonStyle(PlainButtonStyle()) // Xóa hiệu ứng mờ khi bấm
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}